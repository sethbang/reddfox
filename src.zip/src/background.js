browser.action.onClicked.addListener((tab) => {
    if (tab.url.includes("reddit.com")) {
        chrome.tabs.sendMessage(tab.id, { action: "archive" })
            .catch((error) => {
                console.error("Error sending message:", error);
                // If the content script is not loaded, inject and execute it
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    files: ['content.js']
                }).then(() => {
                    // After injection, send the message again
                    return chrome.tabs.sendMessage(tab.id, { action: "archive" });
                }).catch((error) => {
                    console.error("Error executing script:", error);
                });
            });
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "download") {
        fetch(request.url)
            .then(response => response.blob())
            .then(blob => {
                const url = URL.createObjectURL(blob);
                const downloads = browser.downloads || chrome.downloads;
                downloads.download({
                    url: url,
                    filename: request.filename,
                    conflictAction: 'overwrite',
                    saveAs: false
                }, (downloadId) => {
                    if (browser.runtime.lastError) {
                        console.error("Error downloading file:", browser.runtime.lastError);
                    } else {
                        console.log("Download started with ID:", downloadId);
                        URL.revokeObjectURL(url);
                    }
                });
            })
            .catch(error => {
                console.error("Error fetching the data URL:", error);
            });
    }
});