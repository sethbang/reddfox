browser.action.onClicked.addListener((tab) => {
    if (tab.url.includes("reddit.com")) {
        browser.tabs.sendMessage(tab.id, { action: "archive" })
            .catch((error) => {
                console.error("Error sending message:", error);
                // If the content script is not loaded, inject and execute it
                browser.tabs.executeScript(tab.id, { file: 'content.js' })
                    .then(() => {
                        // After injection, send the message again
                        return browser.tabs.sendMessage(tab.id, { action: "archive" });
                    })
                    .catch((error) => {
                        console.error("Error executing script:", error);
                    });
            });
    }
});