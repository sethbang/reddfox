function archiveRedditPage() {
    const posts = [];

    // Wait for posts to load
    function waitForPosts() {
        return new Promise((resolve) => {
            const checkPosts = () => {
                const postElements = document.querySelectorAll('shreddit-post');
                if (postElements.length > 0) {
                    resolve(postElements);
                } else {
                    setTimeout(checkPosts, 100);
                }
            };
            checkPosts();
        });
    }

    waitForPosts().then((postElements) => {
        postElements.forEach(post => {
            const title = post.querySelector('h1[slot="title"]')?.innerText;
            const author = post.getAttribute('author');
            const content = post.querySelector('div[slot="text-body"]')?.innerHTML;
            const timestamp = post.querySelector('faceplate-timeago time')?.getAttribute('datetime');
            const commentCount = post.getAttribute('comment-count');
            const score = post.getAttribute('score');

            if (title && author) {
                posts.push({ title, author, content: content || 'No text content', timestamp, commentCount, score });
            }
        });

        if (posts.length === 0) {
            alert("No posts found on this page. Please make sure you're on a Reddit page with posts.");
            return;
        }

        const htmlContent = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Reddit Archive</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    .post { border: 1px solid #ccc; padding: 10px; margin-bottom: 10px; }
                    .title { font-size: 1.2em; font-weight: bold; }
                    .author { color: #555; }
                    .content { margin-top: 10px; }
                    .timestamp, .comment-count, .score { font-size: 0.9em; color: #777; }
                </style>
            </head>
            <body>
                <h1>Reddit Archive</h1>
                ${posts.map(post => `
                    <div class="post">
                        <div class="title">${post.title}</div>
                        <div class="author">by ${post.author}</div>
                        <div class="timestamp">Posted on: ${new Date(post.timestamp).toLocaleString()}</div>
                        <div class="comment-count">Comments: ${post.commentCount}</div>
                        <div class="score">Score: ${post.score}</div>
                        <div class="content">${post.content}</div>
                    </div>
                `).join('')}
            </body>
            </html>
        `;

        const blob = new Blob([htmlContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'reddit_archive.html';
        a.click();
        URL.revokeObjectURL(url);
    });
}

archiveRedditPage();